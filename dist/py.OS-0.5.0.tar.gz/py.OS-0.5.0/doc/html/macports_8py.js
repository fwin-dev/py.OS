var macports_8py =
[
    [ "MacPortInstaller", "class_o_s_1_1pkg_1_1macports_1_1_mac_port_installer.html", "class_o_s_1_1pkg_1_1macports_1_1_mac_port_installer" ],
    [ "isMacPortOS", "macports_8py.html#a0b70019f184c3b85d41b37a23c888fc4", null ]
];