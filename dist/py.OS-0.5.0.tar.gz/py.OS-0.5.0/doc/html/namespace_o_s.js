var namespace_o_s =
[
    [ "_OS", "namespace_o_s_1_1___o_s.html", "namespace_o_s_1_1___o_s" ],
    [ "DescribeOS", "namespace_o_s_1_1_describe_o_s.html", null ],
    [ "GPG", "namespace_o_s_1_1_g_p_g.html", "namespace_o_s_1_1_g_p_g" ],
    [ "LinuxCommon", "namespace_o_s_1_1_linux_common.html", null ],
    [ "pkg", "namespace_o_s_1_1pkg.html", "namespace_o_s_1_1pkg" ],
    [ "PyVersion", "namespace_o_s_1_1_py_version.html", null ],
    [ "svc", "namespace_o_s_1_1svc.html", null ]
];