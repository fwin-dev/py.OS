var namespace_o_s_1_1pkg_1_1yum =
[
    [ "_YumDummyCallback", "class_o_s_1_1pkg_1_1yum_1_1___yum_dummy_callback.html", "class_o_s_1_1pkg_1_1yum_1_1___yum_dummy_callback" ],
    [ "_EPEL", "class_o_s_1_1pkg_1_1yum_1_1___e_p_e_l.html", "class_o_s_1_1pkg_1_1yum_1_1___e_p_e_l" ],
    [ "YumInstaller", "class_o_s_1_1pkg_1_1yum_1_1_yum_installer.html", "class_o_s_1_1pkg_1_1yum_1_1_yum_installer" ]
];