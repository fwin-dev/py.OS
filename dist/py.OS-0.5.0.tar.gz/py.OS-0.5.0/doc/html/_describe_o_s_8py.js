var _describe_o_s_8py =
[
    [ "isUnix", "_describe_o_s_8py.html#a06251380dc8a9d7f48a3c7d840f02c59", null ],
    [ "__DIST_FUNC", "_describe_o_s_8py.html#a015a47d45775f9236be851de1acd907d", null ],
    [ "flavor", "_describe_o_s_8py.html#a497d597d347e00428cd72e652b911b79", null ],
    [ "version", "_describe_o_s_8py.html#a3f421a92e81608c6629b1bff83a9bf46", null ]
];