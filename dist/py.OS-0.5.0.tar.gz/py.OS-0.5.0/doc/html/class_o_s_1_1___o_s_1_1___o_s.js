var class_o_s_1_1___o_s_1_1___o_s =
[
    [ "__init__", "class_o_s_1_1___o_s_1_1___o_s.html#a4fb297773e6a68d39fca731a36be283b", null ],
    [ "hasRootPermissions", "class_o_s_1_1___o_s_1_1___o_s.html#a418b4ee48548d1af4a20a6d7922dc42b", null ],
    [ "runCMD", "class_o_s_1_1___o_s_1_1___o_s.html#ae96f5e37a5bec97f506bd24cf5b34e46", null ]
];