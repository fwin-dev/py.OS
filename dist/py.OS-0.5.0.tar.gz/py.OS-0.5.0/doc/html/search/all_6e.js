var searchData=
[
  ['needsrepoupdate',['needsRepoUpdate',['../class_o_s_1_1pkg_1_1apt_1_1_apt_installer.html#a21c47218dbbe5327f921d2c1bc464938',1,'OS.pkg.apt.AptInstaller.needsRepoUpdate()'],['../class_o_s_1_1pkg_1_1macports_1_1_mac_port_installer.html#a3d7aa29bbaa90c84ddff1a6c37a178e3',1,'OS.pkg.macports.MacPortInstaller.needsRepoUpdate()'],['../class_o_s_1_1pkg_1_1yum_1_1_yum_installer.html#ae7af6c33118bcc81accf13753c20b533',1,'OS.pkg.yum.YumInstaller.needsRepoUpdate()']]]
];
