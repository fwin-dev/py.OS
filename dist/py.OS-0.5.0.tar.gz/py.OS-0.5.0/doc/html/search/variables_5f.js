var searchData=
[
  ['_5f_5fdist_5ffunc',['__DIST_FUNC',['../namespace_o_s_1_1_describe_o_s.html#a015a47d45775f9236be851de1acd907d',1,'OS::DescribeOS']]],
  ['_5fclass',['_class',['../namespace_o_s_1_1___o_s.html#a38cf5d68454b4620ddefb1f183466530',1,'OS._OS._class()'],['../namespace_o_s_1_1pkg.html#a3e8d2808c1650bc66cd39977f4d4f78a',1,'OS.pkg._class()']]],
  ['_5fthismodule',['_thisModule',['../namespace_o_s_1_1___o_s.html#a031614a61dc38396525adbe467d83679',1,'OS._OS._thisModule()'],['../namespace_o_s_1_1pkg.html#a0e544096c1d4059984fa69291c45f095',1,'OS.pkg._thisModule()']]]
];
