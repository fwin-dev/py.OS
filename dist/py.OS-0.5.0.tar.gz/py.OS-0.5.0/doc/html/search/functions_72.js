var searchData=
[
  ['remove',['remove',['../class_o_s_1_1pkg_1_1apt_1_1_apt_installer.html#af1ebc2d3ced48ecc9020f78029735c2b',1,'OS.pkg.apt.AptInstaller.remove()'],['../class_o_s_1_1pkg_1_1macports_1_1_mac_port_installer.html#a1b9a809fded608fc9669c1c8ce76e6c0',1,'OS.pkg.macports.MacPortInstaller.remove()'],['../class_o_s_1_1pkg_1_1yum_1_1_yum_installer.html#ac39974d4ee37fbc195eda54f2fccc438',1,'OS.pkg.yum.YumInstaller.remove()'],['../namespace_o_s_1_1_linux_common.html#a57bbb57f61d4c71bc90328ea9d4c412f',1,'OS.LinuxCommon.remove()'],['../namespace_o_s_1_1svc.html#a7e5b8dc86f01974f76aa94c6b4b13386',1,'OS.svc.remove()']]],
  ['runcmd',['runCMD',['../class_o_s_1_1___o_s_1_1___o_s.html#ae96f5e37a5bec97f506bd24cf5b34e46',1,'OS::_OS::_OS']]]
];
