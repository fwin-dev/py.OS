var searchData=
[
  ['version',['version',['../namespace_o_s_1_1_describe_o_s.html#a3f421a92e81608c6629b1bff83a9bf46',1,'OS::DescribeOS']]]
];
