var searchData=
[
  ['hasrootpermissions',['hasRootPermissions',['../class_o_s_1_1___o_s_1_1___o_s.html#a418b4ee48548d1af4a20a6d7922dc42b',1,'OS::_OS::_OS']]]
];
