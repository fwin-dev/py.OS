var searchData=
[
  ['describeos_2epy',['DescribeOS.py',['../_describe_o_s_8py.html',1,'']]]
];
