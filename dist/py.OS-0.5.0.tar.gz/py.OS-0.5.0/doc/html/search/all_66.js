var searchData=
[
  ['flavor',['flavor',['../namespace_o_s_1_1_describe_o_s.html#a497d597d347e00428cd72e652b911b79',1,'OS::DescribeOS']]]
];
