var searchData=
[
  ['update',['update',['../class_o_s_1_1pkg_1_1apt_1_1_apt_installer.html#a36a36462b14ae62e73b5a412d878677e',1,'OS.pkg.apt.AptInstaller.update()'],['../class_o_s_1_1pkg_1_1macports_1_1_mac_port_installer.html#a3b8d8ee862329117ef918f30087af8f9',1,'OS.pkg.macports.MacPortInstaller.update()'],['../class_o_s_1_1pkg_1_1yum_1_1_yum_installer.html#ac322dd4d68a0809e878d7cac3502c1da',1,'OS.pkg.yum.YumInstaller.update()']]],
  ['updatekernel',['updateKernel',['../class_o_s_1_1pkg_1_1apt_1_1_apt_installer.html#ae4d8200111cf0813ab86012dddcc836f',1,'OS::pkg::apt::AptInstaller']]]
];
