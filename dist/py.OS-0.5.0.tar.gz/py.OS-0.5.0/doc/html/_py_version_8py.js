var _py_version_8py =
[
    [ "checkSuitablePyExe", "_py_version_8py.html#ab8551391d708cab82df26a9b9e422baa", null ],
    [ "PY_EXE", "_py_version_8py.html#a854e0057f52396ed195874401e447c66", null ]
];