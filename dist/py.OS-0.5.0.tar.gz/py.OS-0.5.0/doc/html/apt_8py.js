var apt_8py =
[
    [ "AptInstaller", "class_o_s_1_1pkg_1_1apt_1_1_apt_installer.html", "class_o_s_1_1pkg_1_1apt_1_1_apt_installer" ],
    [ "isAptOS", "apt_8py.html#a14a7985c0f735ac3c5bb2ac45f10d314", null ]
];