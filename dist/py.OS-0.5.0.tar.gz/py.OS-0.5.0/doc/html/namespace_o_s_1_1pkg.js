var namespace_o_s_1_1pkg =
[
    [ "apt", "namespace_o_s_1_1pkg_1_1apt.html", "namespace_o_s_1_1pkg_1_1apt" ],
    [ "macports", "namespace_o_s_1_1pkg_1_1macports.html", "namespace_o_s_1_1pkg_1_1macports" ],
    [ "yum", "namespace_o_s_1_1pkg_1_1yum.html", "namespace_o_s_1_1pkg_1_1yum" ]
];