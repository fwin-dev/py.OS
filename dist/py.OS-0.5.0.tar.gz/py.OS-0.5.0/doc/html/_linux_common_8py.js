var _linux_common_8py =
[
    [ "remove", "_linux_common_8py.html#a57bbb57f61d4c71bc90328ea9d4c412f", null ]
];