var dir_55e898a8788cd6b0f08be09b3d51822e =
[
    [ "__init__.py", "pkg_2____init_____8py.html", "pkg_2____init_____8py" ],
    [ "apt.py", "apt_8py.html", "apt_8py" ],
    [ "macports.py", "macports_8py.html", "macports_8py" ],
    [ "yum.py", "yum_8py.html", "yum_8py" ]
];