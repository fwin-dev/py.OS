var class_o_s_1_1pkg_1_1yum_1_1___yum_dummy_callback =
[
    [ "event", "class_o_s_1_1pkg_1_1yum_1_1___yum_dummy_callback.html#a8d990f3414dcdeb510b735f902460a44", null ]
];