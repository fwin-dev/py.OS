var namespace_o_s_1_1pkg_1_1apt =
[
    [ "AptInstaller", "class_o_s_1_1pkg_1_1apt_1_1_apt_installer.html", "class_o_s_1_1pkg_1_1apt_1_1_apt_installer" ]
];