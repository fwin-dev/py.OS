var namespaces =
[
    [ "config_parser_m2", "namespaceconfig__parser__m2.html", null ],
    [ "OS", "namespace_o_s.html", "namespace_o_s" ]
];