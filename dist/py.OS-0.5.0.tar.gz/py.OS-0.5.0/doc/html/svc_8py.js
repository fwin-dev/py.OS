var svc_8py =
[
    [ "changeBootState", "svc_8py.html#a1756d868e7ce0d60b1bb12a7533ae8ad", null ],
    [ "changeCurrentState", "svc_8py.html#a8f00839dee1888e98f49c23c0d168bab", null ],
    [ "remove", "svc_8py.html#a7e5b8dc86f01974f76aa94c6b4b13386", null ]
];