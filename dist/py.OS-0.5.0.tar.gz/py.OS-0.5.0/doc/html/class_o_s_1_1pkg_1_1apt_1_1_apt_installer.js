var class_o_s_1_1pkg_1_1apt_1_1_apt_installer =
[
    [ "__init__", "class_o_s_1_1pkg_1_1apt_1_1_apt_installer.html#ae89a8b8f91785f3152e0df85f4d13633", null ],
    [ "install", "class_o_s_1_1pkg_1_1apt_1_1_apt_installer.html#a1288a2bbb73a4afd5b342eda453787a0", null ],
    [ "isAvailable", "class_o_s_1_1pkg_1_1apt_1_1_apt_installer.html#a98697b5e0c523e5395dedc5247549eab", null ],
    [ "isInstalled", "class_o_s_1_1pkg_1_1apt_1_1_apt_installer.html#a9805006eff347a5957a9b4310b97df5c", null ],
    [ "remove", "class_o_s_1_1pkg_1_1apt_1_1_apt_installer.html#af1ebc2d3ced48ecc9020f78029735c2b", null ],
    [ "update", "class_o_s_1_1pkg_1_1apt_1_1_apt_installer.html#a36a36462b14ae62e73b5a412d878677e", null ],
    [ "updateKernel", "class_o_s_1_1pkg_1_1apt_1_1_apt_installer.html#ae4d8200111cf0813ab86012dddcc836f", null ],
    [ "needsRepoUpdate", "class_o_s_1_1pkg_1_1apt_1_1_apt_installer.html#a21c47218dbbe5327f921d2c1bc464938", null ]
];